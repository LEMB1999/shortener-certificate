require('dotenv').config();
const express = require('express');
const cors = require('cors');
const app = express();
const fs = require("fs");
const URL = require('url').URL

// Basic Configuration
const port = process.env.PORT || 3000;

app.use(cors());
app.use(express.urlencoded({ extended: true }));
app.use('/public', express.static(`${process.cwd()}/public`));

app.get('/', function(req, res) {
  res.sendFile(process.cwd() + '/views/index.html');
});

async function readFile(filename) {
  let json = fs.readFileSync(filename,{encoding: 'utf8'});
  return JSON.parse(json);
}

async function saveFile(filename, json) {
  fs.writeFileSync(filename, JSON.stringify(json));
}

async function validateUrl(url){
   try {
    new URL(url);
    return true
   } catch {
    return false
   }
}


// Your first API endpoint
app.post('/api/shorturl', async function(req, res) {
  //validate URL
  const status = await validateUrl(req.body.url);
  if (!status)
      return res.json({ error: 'invalid url' });

  const json = await readFile("./dns.json");
  let shortUrl = `https://boilerplate-project-urlshortener--luisemmanuel2.repl.co/api/shorturl/${json.db.length + 1}`;
  let obj = { "original_url": req.body.url, "short_url_key": json.db.length + 1 };
  json.db.push(obj)
  //save json in file
  await saveFile("./dns.json", json);
  res.status(200).json({ ...obj, short_url: shortUrl });
});

app.get('/api/shorturl/:id', async function(req, res) {
  const json = await readFile("./dns.json");
  const obj = json.db.find((element) => {
    return element["short_url_key"] == req.params.id;
  })
  res.redirect(obj["original_url"]);
});

app.listen(port, function() {
  console.log(`Listening on port ${port}`);
});
